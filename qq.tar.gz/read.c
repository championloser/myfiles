#include"func.h"
int main(int argc,char *argv[])
{
	if(argc!=3){printf("error argc\n");return -1;}
	int fdr=open(argv[1],O_RDONLY);
	int fdw=open(argv[2],O_WRONLY);
	printf("I am a readder\n");
	fd_set rdset;
	struct timeval timeout;
	char buf[128];
	int ret;
	while(1)
	{
		FD_ZERO(&rdset);
		FD_SET(STDIN_FILENO,&rdset);
		FD_SET(fdr,&rdset);
		timeout.tv_sec=5;
		timeout.tv_usec=0;
		ret=select(fdr+1,&rdset,NULL,NULL,&timeout);
		if(ret>0)
		{
			if(FD_ISSET(STDIN_FILENO,&rdset))
			{
				memset(buf,0,sizeof(buf));
				if(read(STDIN_FILENO,buf,sizeof(buf))>0)write(fdw,buf,strlen(buf)-1);
				else {printf("Goodbye\n");break;}
			}
			if(FD_ISSET(fdr,&rdset))
			{
				memset(buf,0,sizeof(buf));
				if(read(fdr,buf,sizeof(buf))>0)printf("%s\n",buf);
				else {printf("Goodbye\n");break;}
			}
		}else{
			printf("There is no anwser\n");
		}
	}
	close(fdr);
	close(fdw);
	return 0;
}
