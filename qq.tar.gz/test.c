#include"func.h"
int main(int argc,char* argv[])
{
	if(argc!=2){printf("error argc\n");return -1;}
	int fdw=open(argv[1],O_WRONLY);
	printf("endding\n");
	return 0;
}
